# Mosallama Student Dashboard

## Requirements
- Java JDK 17 or newer
- A modern browser
- Visual Studio Code (recommended)

## Run the Java backend
1. Open a terminal in the `backend` folder.
2. Compile:
   ```bash
   javac StudentDashboardServer.java
   ```
3. Start:
   ```bash
   java StudentDashboardServer
   ```
4. Keep the terminal running.

## Run the frontend
Open `frontend/index.html` in your browser. For best results, use the VS Code Live Server extension.

The frontend tries to connect to `http://localhost:8080/api`. If the Java backend is not running, grades are saved in browser localStorage as a fallback.

The backend stores grade records in `grades.data` in the backend folder.
